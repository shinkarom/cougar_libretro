var x = 20, y = 0
var dx = 1, dy = 1

function _INIT() {
	_SYS.resolution(128, 128)

}

function _LOOP() {
	if(x < 0 || x + 8 >= 128) {
		dx = -dx
	}
	if (y < 0 || y + 8 >= 128) {
		dy = -dy
	}
	
	x += dx
	y += dy
	
	
	_SYS.clear(0xFF000000)
	
	_SYS.sprite(1, x, y, false, false)
}

module.exports = {_INIT:_INIT, _LOOP:_LOOP}