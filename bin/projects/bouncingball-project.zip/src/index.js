_CONFIG = {WIDTH: 15, HEIGHT: 14}

function writeText(theText,x, y) {
	for(var i = 0; i<theText.length; i++) {
		_SYS.SPRITE(2, x+i*8, y, false, false)
		if(theText[i]!=" "){
		_SYS.SPRITE(1792-33+theText.charCodeAt(i), x+i*8, y, false, false)
		}
	}
}

var x = 15
var y = 15
var dx = 1
var dy = 1

function _INIT() {
	
}

function _LOOP() {
	x += dx
	y += dy
	
	if(x==0 || x+7==240){
		dx = -dx
	}
	if(y==0 || y+7==228){
		dy = -dy
	}
	
	_SYS.CLEAR(0xFF000000)
	_SYS.SPRITE(1, x, y, false, false)
	writeText("HELLO WORLD!", 10,10)
}

module.exports = {_INIT:_INIT, _LOOP:_LOOP, _CONFIG: _CONFIG}